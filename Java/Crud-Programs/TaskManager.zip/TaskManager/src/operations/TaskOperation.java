package operations;

import java.util.Map;
import java.util.Scanner;

import Validation.TaskException;
import core.Task;

public class TaskOperation {

	public static void addTask(Scanner sc, Map<Integer,Task>TaskMap)
	{
		 System.out.println("Enter task details as taskName, description, taskDate");
		 Task t=new Task(sc.next(),sc.next(),sc.next());
		 TaskMap.put(t.getTaskId(), t);
		 System.out.println("Task added successfully !!!");
	}
	
	public static void deleteTask(Scanner sc, Map<Integer,Task>TaskMap) throws TaskException
	{
		 System.out.println("Enter task taskId to delete");
		 int taskId=sc.nextInt();
		 for(Task t:TaskMap.values())
		 {
			 if(t.getTaskId()==taskId) {
				 System.out.println(TaskMap.remove(taskId));
				 t.setActive(false);
				 System.out.println("Current status = "+t.getActive());
			 }
		 }
		throw new TaskException("Task with this TaskId not exists !!!");
	}
	
	public static void updateTask(Scanner sc, Map<Integer,Task>TaskMap) throws TaskException
	{
		System.out.println("Enter task taskId to delete");
		 int taskId=sc.nextInt();
		 for(Task t:TaskMap.values())
		 {
			 if(t.getTaskId()==taskId) {
				 System.out.println("Enter new status(PENDING,COMPLETED,INPROGRESS)");
				 String newStatus=sc.next();
				 if(newStatus.equals("PENDING")||newStatus.equals("COMPLETED")||newStatus.equals("INPROGRESS") )
				 {
					 t.setStatus(newStatus);
					 System.out.println("Status updated successfully");
				 }
			 }
		 
		 }throw new TaskException("Status for this task id not updated");
   }
	
}
