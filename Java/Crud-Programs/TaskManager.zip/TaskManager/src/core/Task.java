package core;

import java.io.Serializable;
import java.time.LocalDate;

public class Task implements Comparable<Task>,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6505246540333859291L;

	private Integer taskId;
	private String taskName;
	private String description;
	private LocalDate taskDate;
	private String status;
	private boolean active;
	private static int count;
	static {count=0;}

	
	
	
	
	public Task(String taskName, String description, String taskDate)
	{
		super();
		this.taskId = ++count;
		this.taskName = taskName;
		this.description = description;
		this.taskDate = LocalDate.parse(taskDate);
		this.status = "PENDING";
		this.active = true;
	}


	public String getStatus() {
		return status;
	}


	public Integer getTaskId() {
		return taskId;
	}


	public String getTaskName() {
		return taskName;
	}

	public String getDescription() {
		return description;
	}

	public LocalDate getTaskDate() {
		return taskDate;
	}

   	
	public boolean getActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}


	

	@Override
	public String toString() {
		return "Task [taskId=" + taskId + ", taskName=" + taskName + ", description=" + description + ", taskDate="
				+ taskDate + ", status=" + status + ", active=" + active + "]";
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + taskId;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Task) {
		  Task t=(Task)obj;
		  return taskId==t.taskId;			 
		}
		 return false;
	}


	@Override
	public int compareTo(Task o) {
		// TODO Auto-generated method stub
		return 0;
	}

}
