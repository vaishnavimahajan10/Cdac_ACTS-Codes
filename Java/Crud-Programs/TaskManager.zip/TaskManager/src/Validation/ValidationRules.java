package Validation;

import java.util.Map;

import core.Task;

public interface ValidationRules {

	public static int DuplicateTaskId(Map<String,Task>TaskMap,int taskId) throws TaskException
	{
		
		for(Task t :TaskMap.values())
		{
			if(t.getTaskId()==taskId)
				throw new TaskException("Task with this id already exists ");
		}
		return taskId;
	}
	
	
	
}
