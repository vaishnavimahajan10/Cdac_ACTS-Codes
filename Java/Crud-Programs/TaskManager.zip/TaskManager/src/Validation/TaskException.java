package Validation;

public class TaskException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6446051959658986333L;
	public TaskException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}


}
