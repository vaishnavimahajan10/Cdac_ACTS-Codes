package core;

import java.time.Duration;
import java.time.LocalDate;

public class Tape extends Publication {

	private Duration playingTime;
	public Tape(String title, Double price, LocalDate publishDate, int rating,long minutes) {
		super(title, price, publishDate, rating);
		// TODO Auto-generated constructor stub
		playingTime=Duration.ofMinutes(minutes);
	}
	@Override
	public String toString() {
		return super.toString()+"Tape playingTime=" + playingTime + "]\n";
	}
	
	

}
