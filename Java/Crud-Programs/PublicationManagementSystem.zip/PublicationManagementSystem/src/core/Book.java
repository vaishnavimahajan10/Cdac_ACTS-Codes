package core;

import java.time.LocalDate;

public class Book extends Publication {
	
	private int count;

	public Book(String title, Double price, LocalDate publishDate, int rating,int count) {
		super(title, price, publishDate, rating);
		// TODO Auto-generated constructor stub
		this.count=count;
	}

	@Override
	public String toString() {
		return super.toString()+"Book count=" + count + "\n";
	}
	

}
