package tester;


import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import core.Book;
import core.Publication;
import core.Tape;

import util.PublicationOperations;
import static util.PublicationOperations.*;

public class PublicationManagement implements PublicationOperations {

	public static void main(String[] args) {
		//initialization phase
		boolean flag=false;
		Map<String,Publication>pMap=new HashMap<>();
		pMap=populatedMap(pMap);
		try (Scanner sc = new Scanner(System.in)) {
			while (!flag) {
				System.out.println("options as :- 1)Add Book\n" + "2)Add Tape\n"
						+ "3)DisplayAll\n" + "4)sortBookByPublishDateDesc\n"
						+ "5)listTop5publisRecentYear\n"
						+ "6)Exit");
				try {
					switch (sc.nextInt()) {
					case 1:
						addBook(sc, pMap);
						break;
					case 2:
						addTape(sc, pMap);
						break;
					case 3:
						displayAll(pMap);
						break;
					case 4:
						sortBookByPublishDateDesc(pMap);
						break;
					case 5:
						listTop5publisRecentYear(pMap);
						break;
				
					case 6:
						flag = true;
						System.out.println("Bye !");
						break;
					default:
						System.out.println("Enter correct choice !");

					}
				} catch (Exception e) {
					e.printStackTrace();
					sc.nextLine();
				}

			}}
		
		
		
		
		
		

	}

	private static Map<String, Publication> populatedMap(Map<String, Publication>pMap) {
		// TODO Auto-generated method stub
		Publication p1=new Book("Physics".toUpperCase(),500.0,LocalDate.parse("2023-05-15"),7,665);
		Publication p2=new Tape("Bollywood".toUpperCase(),1000.0,LocalDate.parse("2022-09-15"),8,360);
		Publication p3=new Book("Chemistry".toUpperCase(),445.0,LocalDate.parse("2023-09-15"),6,700);
		Publication p4=new Tape("Hollywood".toUpperCase(),1500.0,LocalDate.parse("2023-09-15"),9,120);
		Publication p5=new Book("Let's C".toUpperCase(),700.0,LocalDate.parse("2023-08-15"),4,800);
		Publication p6=new Book("Let's C++".toUpperCase(),800.0,LocalDate.parse("2021-10-15"),7,800);
		Publication p7=new Book("Java".toUpperCase(),450.0,LocalDate.parse("2023-10-01"),3,400);
		Publication p8=new Tape("Tollywood".toUpperCase(),300.0,LocalDate.parse("2020-08-15"),2,400);
		pMap.put(p1.getTitle(),p1);
		pMap.put(p2.getTitle(),p2);
		pMap.put(p3.getTitle(),p3);
		pMap.put(p4.getTitle(),p4);
		pMap.put(p5.getTitle(),p5);
		pMap.put(p6.getTitle(),p6);
		pMap.put(p7.getTitle(),p7);
		pMap.put(p8.getTitle(),p8);
		
		
		return pMap;
	}

}
