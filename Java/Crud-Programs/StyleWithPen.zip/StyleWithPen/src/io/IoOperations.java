package io;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.Map;

import core.Pen;

public interface IoOperations {

	static void printData(Map<Integer,Pen>penMap) throws IOException
	{
		try(PrintWriter pw=new PrintWriter(new FileWriter("penData.txt")))
		{
			penMap.forEach((k,v)->pw.println(v));
		}
	}
	static void printDataAsBinary(Map<Integer,Pen>penMap) throws IOException
	{
		try(ObjectOutputStream os=new ObjectOutputStream(new FileOutputStream("penData.ser")))
		{
			os.writeObject(penMap);
		}
	}
	static Map<Integer,Pen> importData(Map<Integer,Pen>penMap) throws IOException, ClassNotFoundException
	{
		try(ObjectInputStream os=new ObjectInputStream(new FileInputStream("penData.ser")))
		{
			return (Map<Integer,Pen>)os.readObject();
		}
	}
}
