package core;

import java.time.LocalDate;
import java.time.LocalTime;

public class Grocery {

	private String name;
	private Double price;
	private Integer quantity;
	private LocalDate date;
	private LocalTime time;
	public Grocery(String name, Double price, Integer quantity, LocalDate date, LocalTime time) {
		super();
		this.name = name;
		this.price = price;
		this.quantity = quantity;
		this.date = date;
		this.time = time;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
		
	}
	@Override
	public String toString() {
		return "Grocery [name=" + name + ",price=" + price + ",quantity=" + quantity + "]\n";
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public void setTime(LocalTime time) {
		this.time = time;
	}
	public String getName() {
		return name;
	}

	
	
	
	
}
