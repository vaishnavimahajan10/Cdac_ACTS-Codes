package tester;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import core.Grocery;
import util.GroceryServices;
import static util.GroceryServices.*;

public class GroceryManagement implements GroceryServices {

	public static void main(String[] args) {
		
		// Initialization Phase start
				boolean flag = false;
				Map<String,Grocery> groceryMap = new HashMap<>();
				populatedMap(groceryMap);
				try (Scanner sc = new Scanner(System.in)) { 
					while (!flag) {
						System.out.println("1)Add new Item \n" + "2)Update stock \n" + "3)Display all Item\n"
								+ "4)remove all out of stock item\n" + "5)display all item who recently dislay(in 3 days)\n" +"6.exit\n");
						try { 
							switch (sc.nextInt()) {
							case 1:
								addNewItem(sc, groceryMap);
								break;
							case 2:
								update(sc,groceryMap);
								break;
							case 3:
								displayItem(groceryMap);
								break;
							case 4:
								removeEmptyItem(groceryMap);
								break;
							case 5:
								displayItemRecentUpdated(groceryMap,3);
								break;
							case 6:
								flag=true;
								System.out.println("Bye !");
								break;
						
							default:
								System.out.println("Invalid choice !");
								break;
							}
						} catch (Exception e) {
							e.printStackTrace();
							sc.nextLine();
						}
					}
	}

}}
