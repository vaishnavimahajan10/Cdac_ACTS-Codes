package petException;

public class OutOfStockException extends Exception {

	
	public OutOfStockException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}


}
