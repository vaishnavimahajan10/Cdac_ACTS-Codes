package petException;

public class AuthenticationException extends Exception {

	public AuthenticationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
