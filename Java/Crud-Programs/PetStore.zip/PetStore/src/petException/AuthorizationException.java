package petException;

public class AuthorizationException extends Exception {

	

	public AuthorizationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}



}
