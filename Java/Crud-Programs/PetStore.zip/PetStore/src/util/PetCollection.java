package util;

import java.io.Serializable;

public interface PetCollection extends Serializable {


	// it is marker interface use to hold instace of implement classes.
}
