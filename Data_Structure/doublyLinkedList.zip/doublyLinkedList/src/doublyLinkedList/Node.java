package doublyLinkedList;

public class Node {
 int data;
 Node previous;
 Node next;
Node(int data){
	this.data=data;
	previous=null;
	next=null;
}

}
