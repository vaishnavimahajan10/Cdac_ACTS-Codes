module doublyLinkedList {
}