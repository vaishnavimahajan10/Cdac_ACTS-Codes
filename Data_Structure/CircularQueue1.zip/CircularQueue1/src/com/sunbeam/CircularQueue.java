package com.sunbeam;

public class CircularQueue {
	private int[] arr;
	private int front, rear;
	private int count;
	private final int SIZE;
	public CircularQueue(int size) {
		SIZE = size;
		arr = new int[SIZE];
		front = -1;
		rear = -1;
		count = 0;
	}
	
	public void push(int data) {
		//1. reposition rear (inc)
		rear = (rear + 1) % SIZE;
		//2. add data(element) at rear index
		arr[rear] = data;
		//3. increament count
		count++;
	}
	
	public void pop() {
		//1. reposition front (inc)
		front = (front + 1) % SIZE;
		//2. decrement count
		count--;
	}
	
	public int peek() {
		// 1. read data from front end (front + 1 index)
		return arr[(front + 1) % SIZE];
	}
	
	public boolean isEmpty() {
		return count == 0;
	}
	
	public boolean isFull() {
		return count == SIZE;
	}
}







