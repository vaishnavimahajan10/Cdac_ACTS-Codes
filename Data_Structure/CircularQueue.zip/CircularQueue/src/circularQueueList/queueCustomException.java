package circularQueueList;

public class queueCustomException extends Exception{

	public queueCustomException(String str)
	{
		super(str);
	}
}
