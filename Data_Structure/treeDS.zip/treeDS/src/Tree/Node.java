package Tree;

public class Node {
int value;
Node left;
Node right;
Node(int data){
	value=data;
	left=null;
	right=null;
}
}
