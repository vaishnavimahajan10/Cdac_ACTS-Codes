package Array;

public class ArrayCustomException extends Exception {
	public ArrayCustomException(String str) {
		super(str);
	}

}
