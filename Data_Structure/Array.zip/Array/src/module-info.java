module ArrayDs {
}