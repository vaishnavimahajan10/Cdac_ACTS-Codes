module searchAlgorithms {
}